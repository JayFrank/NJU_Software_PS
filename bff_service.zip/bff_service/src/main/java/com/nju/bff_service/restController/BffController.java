package com.nju.bff_service.restController;

import com.nju.bff_service.restController.info.LoginInfo;
import com.nju.bff_service.restController.info.OrderInfo;
import com.nju.bff_service.restController.info.RefundInfo;
import com.nju.bff_service.restController.info.UserInfo;
import com.nju.bff_service.restController.vo.*;
import com.nju.bff_service.service.BffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;

@RestController
@RequestMapping("/bff")
public class BffController {
    @Autowired
    BffService bffService;

    @RequestMapping(value = "/health", method = RequestMethod.GET)
    public ResultVO health(){
        return new ResultVO("health is ok!", 1);
    }

    @RequestMapping(value = "/remote/health", method = RequestMethod.GET)
    public ResultVO remoteHealth(){
        return new ResultVO(bffService.health("http://127.0.0.1:8000/cart/health"), 1);
    }

    //register
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public ResultVO register(@RequestBody UserInfo registerInfo){
        if (bffService.addUser(registerInfo) == 1){
            return new ResultVO("success", 1);
        }
        return new ResultVO("fail", 0);
    }

    //login
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ResultVO login(@RequestBody LoginInfo loginInfo, HttpSession session){
        int id = bffService.login(loginInfo);
        if (id >= 0){
            session.setAttribute("userId", id);
            return new ResultVO("success", 1);
        }
        return new ResultVO("fail", 0);
    }

    //list my orders
    @RequestMapping(value = "/orders", method = RequestMethod.GET)
    public OrderListVO getOrders(HttpSession session){
        int uid = (Integer) session.getAttribute("userId");
        return bffService.getOrders(uid);
    }

    //order detail
    @RequestMapping(value = "/order/{oid}", method = RequestMethod.GET)
    public OrderVO getOrder(@PathVariable Integer oid){
        return bffService.getOrder(oid);
    }

    //refund
    @RequestMapping(value = "/refund", method = RequestMethod.POST)
    public ResultVO refund(@RequestBody RefundInfo refundInfo){
        if (bffService.refund(refundInfo) == 1){
            return new ResultVO("success", 1);
        }
        return new ResultVO("fail", 0);
    }

    //buy
    @RequestMapping(value = "/buy", method = RequestMethod.POST)
    public ResultVO buy(@RequestBody OrderInfo orderInfo){
        if (bffService.buy(orderInfo) == 1){
            return new ResultVO("success", 1);
        }
        return new ResultVO("fail", 0);
    }

    //list category
    @RequestMapping(value = "/category", method = RequestMethod.GET)
    public CategoryListVO getCategory(){
        return bffService.getCategories();
    }

    //list pets
    @RequestMapping(value = "/pets/{cid}", method = RequestMethod.GET)
    public PetListVO getPet(@PathVariable Integer cid){
        return bffService.getPets(cid);
    }

    //update my info
    @RequestMapping(value = "/account/update", method = RequestMethod.POST)
    public ResultVO updateUser(@RequestBody UserInfo userInfo){
        if (bffService.addUser(userInfo) == 1){
            return new ResultVO("success", 1);
        }
        return new ResultVO("fail", 0);
    }
}
