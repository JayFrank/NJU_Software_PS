package com.nju.bff_service.restController.info;

public class RefundInfo {
    int orderId;

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getOrderId() {

        return orderId;
    }
}
