package com.nju.raychen.pet_store_pet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetStorePetApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetStorePetApplication.class, args);
	}
}
