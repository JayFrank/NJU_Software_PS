package com.nju.raychen.pet_store_pet.restController.info;

public class PetInfo {
    String pet_name;
    int store;
    double price;
    int cid;
    int id;
    String desc;

    public void setPet_name(String pet_name) {
        this.pet_name = pet_name;
    }

    public void setStore(int store) {
        this.store = store;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getPet_name() {

        return pet_name;
    }

    public int getStore() {
        return store;
    }

    public double getPrice() {
        return price;
    }

    public int getCid() {
        return cid;
    }

    public int getId() {
        return id;
    }

    public String getDesc() {
        return desc;
    }
}
