package com.nju.raychen.pet_store_pet.service;

import com.nju.raychen.pet_store_pet.restController.info.PetInfo;
import com.nju.raychen.pet_store_pet.restController.info.PetListInfo;
import com.nju.raychen.pet_store_pet.restController.vo.ResultVO;

import java.util.List;

public interface PetService {

    public int addPet(PetInfo petInfo);
    public PetInfo getPet(int id);
    public PetInfo getPet(String name);
    public PetListInfo getPets(String petName);
    public PetListInfo getPets(int cid);
}
