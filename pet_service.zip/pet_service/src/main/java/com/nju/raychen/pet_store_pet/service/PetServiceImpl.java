package com.nju.raychen.pet_store_pet.service;

import com.nju.raychen.pet_store_pet.dao.PetDAO;
import com.nju.raychen.pet_store_pet.model.PetEntity;
import com.nju.raychen.pet_store_pet.restController.info.PetInfo;
import com.nju.raychen.pet_store_pet.restController.info.PetListInfo;
import com.nju.raychen.pet_store_pet.restController.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PetServiceImpl implements PetService {

    @Autowired
    PetDAO petDAO;

    @Override
    public int addPet(PetInfo petInfo) {
        Integer id = petInfo.getId();
        PetEntity petEntity = null;
        if (id == -1) {
            id = petDAO.findMaxId();
            if (id == null) id = 0;
            id++;
            petEntity = new PetEntity();
            petEntity.setId(id);
        } else {
            petEntity = petDAO.getOne(id);
        }
        petEntity.setCategoryId(petInfo.getCid());
        petEntity.setPetName(petInfo.getPet_name());
        petEntity.setStore(petInfo.getStore());
        petEntity.setSinglePrice(petInfo.getPrice());
        petDAO.save(petEntity);
        petDAO.flush();
        return 1;
    }

    @Override
    public PetInfo getPet(int id) {
        PetEntity petEntity = petDAO.getOne(id);
        PetInfo petInfo = new PetInfo();
        petInfo.setId(petEntity.getId());
        petInfo.setCid(petEntity.getCategoryId());
        petInfo.setPet_name(petEntity.getPetName());
        petInfo.setPrice(petEntity.getSinglePrice());
        petInfo.setStore(petEntity.getStore());
        return petInfo;
    }

    @Override
    public PetInfo getPet(String name) {
        PetEntity petEntity = petDAO.findPetEntityByPetName(name);
        PetInfo petInfo = new PetInfo();
        petInfo.setId(petEntity.getId());
        petInfo.setCid(petEntity.getCategoryId());
        petInfo.setPet_name(petEntity.getPetName());
        petInfo.setPrice(petEntity.getSinglePrice());
        petInfo.setStore(petEntity.getStore());
        return petInfo;
    }

    @Override
    public PetListInfo getPets(String petName) {
        List<PetEntity> petEntities = petDAO.findPetEntitiesByPetNameLike(petName);
        PetListInfo petListInfo = new PetListInfo();
        List<PetInfo> petInfos = new ArrayList<>();
        for (PetEntity petEntity : petEntities) {
            PetInfo petInfo = new PetInfo();
            petInfo.setId(petEntity.getId());
            petInfo.setCid(petEntity.getCategoryId());
            petInfo.setPet_name(petEntity.getPetName());
            petInfo.setPrice(petEntity.getSinglePrice());
            petInfo.setStore(petEntity.getStore());
            petInfos.add(petInfo);
        }
        petListInfo.setPetInfos(petInfos);
        return petListInfo;
    }

    @Override
    public PetListInfo getPets(int cid) {
        List<PetEntity> petEntities = petDAO.findPetEntitiesByCategoryId(cid);
        PetListInfo petListInfo = new PetListInfo();
        List<PetInfo> petInfos = new ArrayList<>();
        for (PetEntity petEntity : petEntities) {
            PetInfo petInfo = new PetInfo();
            petInfo.setId(petEntity.getId());
            petInfo.setCid(cid);
            petInfo.setPet_name(petEntity.getPetName());
            petInfo.setPrice(petEntity.getSinglePrice());
            petInfo.setStore(petEntity.getStore());
            petInfos.add(petInfo);
        }
        petListInfo.setPetInfos(petInfos);
        return petListInfo;
    }
}
