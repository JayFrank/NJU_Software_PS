package com.nju.raychen.pet_store_category.dao;

import com.nju.raychen.pet_store_category.model.CategoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CategoryDAO extends JpaRepository<CategoryEntity, Integer> {

    @Query("select max(entity.id) from CategoryEntity entity")
    Integer findMaxId();
}
