package com.nju.raychen.pet_store_category.service;

import com.nju.raychen.pet_store_category.restController.info.CategoryInfo;
import com.nju.raychen.pet_store_category.restController.info.CategoryListInfo;

public interface CategoryService {
    CategoryInfo getCategory(Integer id);
    CategoryListInfo getCategories();
    int addCategory(CategoryInfo categoryInfo);
}
