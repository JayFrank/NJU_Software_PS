package com.nju.raychen.pet_store_category;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetStoreCategoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetStoreCategoryApplication.class, args);
	}
}
