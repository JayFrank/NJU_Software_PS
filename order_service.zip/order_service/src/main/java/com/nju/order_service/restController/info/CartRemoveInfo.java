package com.nju.order_service.restController.info;

public class CartRemoveInfo {
    int cartItemId;

    public void setCartItemId(int cartItemId) {
        this.cartItemId = cartItemId;
    }

    public int getCartItemId() {

        return cartItemId;
    }
}
