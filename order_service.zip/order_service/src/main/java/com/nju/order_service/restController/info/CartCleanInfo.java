package com.nju.order_service.restController.info;

public class CartCleanInfo {
    int userId;

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getUserId() {

        return userId;
    }
}
